﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Advice : Form
    {
        public Advice()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (judgetime.Text == "")
            {
                //提示对话框
                MessageBox.Show(this, "评分周期不能为空！请选择！", "提示对话框", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
                string _sql = "select judgecircle.judgecirclename as '评分周期',advice as '学生意见',result as '处理结果',"
                              + "teacherid as '导员教工号' from  adre,judgecircle where adre.judgecirclename=judgecircle.judgecirclename ";

                if (judgetime.SelectedValue.ToString().Trim() == "-1") { }
                else
                {
                    _sql = _sql + " and judgecircle.judgecircleid='" + judgetime.SelectedValue + "'";
                }

                SqlConnection conn = new SqlConnection(connStr);
                SqlDataAdapter sda = new SqlDataAdapter(_sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                DataTable _table = ds.Tables[0];
                int count = _table.Rows.Count;
                scoregdv.DataSource = ds.Tables[0].DefaultView;
                conn.Close();

            }
        }
        private void AdviceForm_Load(object sender, EventArgs e)//下拉列表的数据导入
        {
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from judgecircle";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(selectsql, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataTable _table = ds.Tables[0];

            judgetime.DataSource = _table;
            judgetime.DisplayMember = "judgecirclename";
            judgetime.ValueMember = "judgecircleid";



        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            StuForm s = new StuForm();
            s.Show();
            this.Hide();
            
            
            TeacherForm sa= new TeacherForm();
            sa.Show();
            this.Hide();
            
        }
    }
}
