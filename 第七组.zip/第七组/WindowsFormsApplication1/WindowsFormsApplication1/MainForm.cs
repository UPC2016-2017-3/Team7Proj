﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from Teacher where teacherid = '" + textBox1.Text + "' and teapassword='" + textBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr;
            sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {

                this.DialogResult = System.Windows.Forms.DialogResult.OK;

            }
            else
            {
                MessageBox.Show("请检查账号密码重新登录！",
                             "登陆失败！",
                             MessageBoxButtons.OK,
                             MessageBoxIcon.Information);
                return;
            }
            conn.Close();
            TeacherForm f11 = new TeacherForm();
            this.Hide();
            f11.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from Student where stuid = '" + textBox1.Text + "' and stupassword='" + textBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr;
            sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {

                this.DialogResult = System.Windows.Forms.DialogResult.OK;

            }
            else
            {
                MessageBox.Show("请检查账号密码重新登录！",
                                 "登陆失败！",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                return;
            }
            conn.Close();
            StuForm f12 = new StuForm();
            this.Hide();
            f12.Show();
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string strName = textBox1.Text.Trim();
            string strPWD = textBox2.Text.Trim();
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from Student where atuority='yes' and stuid = '" + textBox1.Text + "' and stupassword='" + textBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr;
            sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {

                this.DialogResult = System.Windows.Forms.DialogResult.OK;
                MessageBox.Show("欢迎进行本次评分！",
                                 "验证成功！",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                conn.Close();
                JudgeForm f12 = new JudgeForm();
                this.Hide();
                f12.Show();
                return;

            }
            else 
            {
                MessageBox.Show("登陆失败！请检查账号密码重新登录！",
                                 "验证失败",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                return;
            }
         

        }



    }
}

