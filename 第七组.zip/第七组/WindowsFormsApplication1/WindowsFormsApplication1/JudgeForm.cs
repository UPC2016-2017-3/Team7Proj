﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class JudgeForm : Form
    {
        public JudgeForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        { }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("确认退出？",
                                 "提示！",
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Information);
            MainForm f1 = new MainForm();
            this.Hide();
            f1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*) from judgecircle where judgecircleid='" + judgecircleid.Text + "'";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                if (judgetime.Text.Trim() == "" || judgecircleid.Text.Trim() == "")
                {
                    MessageBox.Show("输入不能为空！",
                                     "错误！",
                                     MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);
                }
                else
                {
                    conn.Open();
                    //添加新记录
                    _sql = "insert into judgecircle(judgecircleid,judgecirclename) values('" + judgecircleid.Text.Trim() + "','" + judgetime.Text.Trim() + "')";
                    cmd = new SqlCommand(_sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("提交成功！",
                                     "提示",
                                     MessageBoxButtons.OK,
                                     MessageBoxIcon.Information);

                    time.Hide();
                    scoregb.BringToFront();
                }
            }
            finally
            {
                conn.Close();
            }
            l6.Hide();
            tb6.Hide();
            
        }

        private void scorebtn_Click(object sender, EventArgs e)
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*)  from Score sequence";
            
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                conn.Open();
                int cnt = (int)cmd.ExecuteScalar();
                if(sequence.Text.Trim()==""|| buildingid.Text.Trim()==""|| roomid.Text.Trim()== ""||score.Text.Trim()==""||tb3.Text.Trim()=="")
                {
                    MessageBox.Show("输入不能为空！",
                                       "错误！",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                }          
                else
                {
                    _sql = "insert into Score(buildingid,roomid,scores,judgecircleid,stuid) "
                             + "values('" + buildingid.Text.Trim() + "','" + roomid.Text.Trim() + "','" + score.Text.Trim() + "','" +judgecircleid.Text.Trim() + "','" + tb3.Text.Trim()+ "')";                  
                cmd = new SqlCommand(_sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("更新成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);

                sequence.Clear();
                roomid.Clear();
                score.Clear();
                l3.Hide();
                l4.Hide();
                tb3.Hide();              
                buildingid.Hide();
              

            }}
            finally
            {
                conn.Close();
            }
}

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }

        
   
}


