﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Manage : Form
    {
        public Manage()
        {
            InitializeComponent();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            TeacherForm f = new TeacherForm();
            this.Hide();
            f.Show();
        }

        private void Manage_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
  
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void collage_Paint(object sender, PaintEventArgs e)
        {

        }
        private void 确认添加学生信息_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)//添加导员信息
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*) from Teacher where teacherid='" + teacherid.Text + "'";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                conn.Open(); 
                int cnt = (int)cmd.ExecuteScalar();
                //修改记录
                if (cnt == 1)
                {
                    _sql = "Update Teacher set teacherid='" + teacherid.Text.Trim() + "' and collageid='" + collageid1.Text.Trim() + "'"
                            + "teachername='" + teachername.Text.Trim() + "',teapasswored='" + teapassword.Text.Trim() + "'";
                }
                //添加新记录
                else
                {
                    _sql = "insert into Teacher(teacherid,teachername,collageid,teapassword) values('" + teacherid.Text.Trim() + "','" + teachername.Text.Trim() + "','" + collageid1.Text.Trim() + "','" + teapassword.Text.Trim() + "')";
                }
                    cmd = new SqlCommand(_sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("更新成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }


        private void button3_Click(object sender, EventArgs e)//添加寝室信息
        {
            
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";  
            string _sql = "select count(*) from Bedroom num";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
           
            try
            {
                conn.Open();   
                int cnt = (int)cmd.ExecuteScalar();
                //修改记录
                if (cnt == 1)
                {
                    _sql = "Update Bedroom set roomid='" + collageid.Text.Trim() + "' and buildingid='" + collagename.Text.Trim() + "'";
                }
                //添加新记录
                else
                {
                    _sql = "insert into Bedroom(roomid,buildingid) values('" + roomid.Text.Trim() + "','" + buildingid.Text.Trim() + "')";
                }
                    cmd = new SqlCommand(_sql, conn);

                cmd.ExecuteNonQuery();
                roomid.Controls.Clear();
                MessageBox.Show("更新成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);  
              roomid.Clear();
                   
            }
            finally
            {
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)//添加学院信息
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*) from Collage where collageid='" + collageid.Text + "' ";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                conn.Open();
                int cnt = (int)cmd.ExecuteScalar();
                //修改记录
                if (cnt == 1)
                {
                     _sql = "Update Collage set collageid='" + collageid.Text.Trim() + "' and collagenameid='" + collagename.Text.Trim() + "'";
                }
                //添加新记录
                else
                {
                    _sql = "insert into Collage(collageid,collagename) values('" + collageid.Text.Trim() + "','" + collagename.Text.Trim() + "')";
                }
                cmd = new SqlCommand(_sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("添加成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)//添加打分学生信息
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*) from Student where stuid='"+stuid.Text+"'";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                conn.Open();
                int cnt = (int)cmd.ExecuteScalar();
                //修改记录
                if (cnt == 1)
                {

                    _sql = "update Student set stuname='" + stuname.Text.Trim() + "',"
                            +"atuority='" + authority.Text.Trim() + "',stupassword='" + stupassword.Text.Trim() + "'where stuid='" + stuid.Text.Trim() + "'";
                }
                else
                {
                    _sql = "insert into Student(stuid,stuname,stupassword,atuority) values('" +stuid.Text+ "','" + stuname.Text + "','" + stupassword.Text + "','" + authority.Text + "')";
                }
                cmd = new SqlCommand(_sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("更新成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }

        private void 寝室添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bedroom.BringToFront();
          
        }

        private void 学院添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            collage1.BringToFront();
        }

        private void 导员添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            teacher.BringToFront();
        }

        private void 评分学生添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stu.BringToFront();
        }

   
     
        }
        
}
