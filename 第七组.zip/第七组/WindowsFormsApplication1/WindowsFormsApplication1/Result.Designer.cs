﻿namespace WindowsFormsApplication1
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.submitadvice = new System.Windows.Forms.GroupBox();
            this.judgetime = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            this.advice = new System.Windows.Forms.RichTextBox();
            this.lq = new System.Windows.Forms.Label();
            this.teacherid = new System.Windows.Forms.TextBox();
            this.submitadvice.SuspendLayout();
            this.SuspendLayout();
            // 
            // submitadvice
            // 
            this.submitadvice.Controls.Add(this.teacherid);
            this.submitadvice.Controls.Add(this.lq);
            this.submitadvice.Controls.Add(this.judgetime);
            this.submitadvice.Controls.Add(this.label5);
            this.submitadvice.Controls.Add(this.submit);
            this.submitadvice.Controls.Add(this.advice);
            this.submitadvice.Location = new System.Drawing.Point(23, 61);
            this.submitadvice.Name = "submitadvice";
            this.submitadvice.Size = new System.Drawing.Size(840, 568);
            this.submitadvice.TabIndex = 13;
            this.submitadvice.TabStop = false;
            this.submitadvice.Text = "意见上传";
            // 
            // judgetime
            // 
            this.judgetime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.judgetime.FormattingEnabled = true;
            this.judgetime.Location = new System.Drawing.Point(171, 48);
            this.judgetime.Name = "judgetime";
            this.judgetime.Size = new System.Drawing.Size(121, 23);
            this.judgetime.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "请选择打分周期：";
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(697, 511);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(95, 33);
            this.submit.TabIndex = 1;
            this.submit.Text = "确认提交";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click_1);
            // 
            // advice
            // 
            this.advice.Location = new System.Drawing.Point(22, 113);
            this.advice.Name = "advice";
            this.advice.Size = new System.Drawing.Size(782, 392);
            this.advice.TabIndex = 0;
            this.advice.Text = "";
            // 
            // lq
            // 
            this.lq.AutoSize = true;
            this.lq.Location = new System.Drawing.Point(345, 53);
            this.lq.Name = "lq";
            this.lq.Size = new System.Drawing.Size(112, 15);
            this.lq.TabIndex = 12;
            this.lq.Text = "请输入教工号：";
            // 
            // teacherid
            // 
            this.teacherid.Location = new System.Drawing.Point(446, 48);
            this.teacherid.Name = "teacherid";
            this.teacherid.Size = new System.Drawing.Size(100, 25);
            this.teacherid.TabIndex = 13;
            // 
            // Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 691);
            this.Controls.Add(this.submitadvice);
            this.Name = "Result";
            this.Text = "导员意见处理";
            this.Load += new System.EventHandler(this.ResultForm_Load);
            this.submitadvice.ResumeLayout(false);
            this.submitadvice.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox submitadvice;
        private System.Windows.Forms.TextBox teacherid;
        private System.Windows.Forms.Label lq;
        private System.Windows.Forms.ComboBox judgetime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.RichTextBox advice;
    }
}