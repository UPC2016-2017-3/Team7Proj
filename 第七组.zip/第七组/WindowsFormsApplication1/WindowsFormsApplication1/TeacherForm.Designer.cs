﻿namespace WindowsFormsApplication1
{
    partial class TeacherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.意见处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.结果及意见查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.modify = new System.Windows.Forms.GroupBox();
            this.query = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buildingid = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.roomid = new System.Windows.Forms.Label();
            this.scoregdv = new System.Windows.Forms.DataGridView();
            this.roomid1 = new System.Windows.Forms.TextBox();
            this.judgetime = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.newpassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cuspassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.accouts = new System.Windows.Forms.Label();
            this.teacherid = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.modify.SuspendLayout();
            this.query.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(882, 652);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 35);
            this.button4.TabIndex = 4;
            this.button4.Text = "退出";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("宋体", 9F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询ToolStripMenuItem,
            this.意见处理ToolStripMenuItem,
            this.新增ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.结果及意见查询ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(55, 21);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(418, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "请选择";
            // 
            // 查询ToolStripMenuItem
            // 
            this.查询ToolStripMenuItem.Name = "查询ToolStripMenuItem";
            this.查询ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.查询ToolStripMenuItem.Text = "结果查询";
            this.查询ToolStripMenuItem.Click += new System.EventHandler(this.查询ToolStripMenuItem_Click);
            // 
            // 意见处理ToolStripMenuItem
            // 
            this.意见处理ToolStripMenuItem.Name = "意见处理ToolStripMenuItem";
            this.意见处理ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.意见处理ToolStripMenuItem.Text = "意见处理";
            this.意见处理ToolStripMenuItem.Click += new System.EventHandler(this.意见处理ToolStripMenuItem_Click);
            // 
            // 新增ToolStripMenuItem
            // 
            this.新增ToolStripMenuItem.Name = "新增ToolStripMenuItem";
            this.新增ToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.新增ToolStripMenuItem.Text = "新增";
            this.新增ToolStripMenuItem.Click += new System.EventHandler(this.新增ToolStripMenuItem_Click);
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 结果及意见查询ToolStripMenuItem
            // 
            this.结果及意见查询ToolStripMenuItem.Name = "结果及意见查询ToolStripMenuItem";
            this.结果及意见查询ToolStripMenuItem.Size = new System.Drawing.Size(124, 20);
            this.结果及意见查询ToolStripMenuItem.Text = "结果及意见查询";
            this.结果及意见查询ToolStripMenuItem.Click += new System.EventHandler(this.结果及意见查询ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.query);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.menuStrip1);
            this.groupBox1.Controls.Add(this.modify);
            this.groupBox1.Location = new System.Drawing.Point(21, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(968, 693);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请选择";
            // 
            // modify
            // 
            this.modify.Controls.Add(this.button3);
            this.modify.Controls.Add(this.newpassword);
            this.modify.Controls.Add(this.label4);
            this.modify.Controls.Add(this.cuspassword);
            this.modify.Controls.Add(this.label3);
            this.modify.Controls.Add(this.accouts);
            this.modify.Controls.Add(this.teacherid);
            this.modify.Location = new System.Drawing.Point(68, 58);
            this.modify.Name = "modify";
            this.modify.Size = new System.Drawing.Size(815, 577);
            this.modify.TabIndex = 4;
            this.modify.TabStop = false;
            this.modify.Text = "修改密码";
            // 
            // query
            // 
            this.query.Controls.Add(this.label2);
            this.query.Controls.Add(this.buildingid);
            this.query.Controls.Add(this.button2);
            this.query.Controls.Add(this.roomid);
            this.query.Controls.Add(this.scoregdv);
            this.query.Controls.Add(this.roomid1);
            this.query.Controls.Add(this.judgetime);
            this.query.Controls.Add(this.label1);
            this.query.Controls.Add(this.button1);
            this.query.Location = new System.Drawing.Point(68, 58);
            this.query.Name = "query";
            this.query.Size = new System.Drawing.Size(815, 577);
            this.query.TabIndex = 10;
            this.query.TabStop = false;
            this.query.Text = "结果查询";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(384, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "楼号：";
            // 
            // buildingid
            // 
            this.buildingid.Location = new System.Drawing.Point(442, 60);
            this.buildingid.Name = "buildingid";
            this.buildingid.Size = new System.Drawing.Size(100, 25);
            this.buildingid.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(194, 108);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 26);
            this.button2.TabIndex = 9;
            this.button2.Text = "确认";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // roomid
            // 
            this.roomid.AutoSize = true;
            this.roomid.Location = new System.Drawing.Point(369, 116);
            this.roomid.Name = "roomid";
            this.roomid.Size = new System.Drawing.Size(67, 15);
            this.roomid.TabIndex = 8;
            this.roomid.Text = "寝室号：";
            // 
            // scoregdv
            // 
            this.scoregdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scoregdv.Location = new System.Drawing.Point(61, 151);
            this.scoregdv.Name = "scoregdv";
            this.scoregdv.RowTemplate.Height = 27;
            this.scoregdv.Size = new System.Drawing.Size(623, 319);
            this.scoregdv.TabIndex = 0;
            // 
            // roomid1
            // 
            this.roomid1.Location = new System.Drawing.Point(442, 108);
            this.roomid1.Name = "roomid1";
            this.roomid1.Size = new System.Drawing.Size(100, 25);
            this.roomid1.TabIndex = 7;
            // 
            // judgetime
            // 
            this.judgetime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.judgetime.FormattingEnabled = true;
            this.judgetime.Location = new System.Drawing.Point(156, 60);
            this.judgetime.Name = "judgetime";
            this.judgetime.Size = new System.Drawing.Size(121, 23);
            this.judgetime.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "打分周期：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(556, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 28);
            this.button1.TabIndex = 3;
            this.button1.Text = "确认";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(372, 295);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(117, 35);
            this.button3.TabIndex = 13;
            this.button3.Text = "确认修改";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // newpassword
            // 
            this.newpassword.Location = new System.Drawing.Point(339, 207);
            this.newpassword.Name = "newpassword";
            this.newpassword.Size = new System.Drawing.Size(150, 25);
            this.newpassword.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "请输入新密码：";
            // 
            // cuspassword
            // 
            this.cuspassword.Location = new System.Drawing.Point(339, 159);
            this.cuspassword.Name = "cuspassword";
            this.cuspassword.Size = new System.Drawing.Size(150, 25);
            this.cuspassword.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(194, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "请输入旧密码：";
            // 
            // accouts
            // 
            this.accouts.AutoSize = true;
            this.accouts.Location = new System.Drawing.Point(250, 121);
            this.accouts.Name = "accouts";
            this.accouts.Size = new System.Drawing.Size(52, 15);
            this.accouts.TabIndex = 8;
            this.accouts.Text = "账号：";
            // 
            // teacherid
            // 
            this.teacherid.Location = new System.Drawing.Point(339, 111);
            this.teacherid.Name = "teacherid";
            this.teacherid.Size = new System.Drawing.Size(150, 25);
            this.teacherid.TabIndex = 7;
            // 
            // TeacherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 731);
            this.Controls.Add(this.groupBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "TeacherForm";
            this.Text = "TeacherForm";
            this.Load += new System.EventHandler(this.TeacherForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.modify.ResumeLayout(false);
            this.modify.PerformLayout();
            this.query.ResumeLayout(false);
            this.query.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 意见处理ToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripMenuItem 新增ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.GroupBox query;
        private System.Windows.Forms.Label roomid;
        private System.Windows.Forms.DataGridView scoregdv;
        private System.Windows.Forms.TextBox roomid1;
        private System.Windows.Forms.ComboBox judgetime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox modify;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox newpassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cuspassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label accouts;
        private System.Windows.Forms.TextBox teacherid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox buildingid;
        private System.Windows.Forms.ToolStripMenuItem 结果及意见查询ToolStripMenuItem;
    }
}