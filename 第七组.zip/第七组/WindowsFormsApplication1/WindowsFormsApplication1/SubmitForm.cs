﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class SubmitForm : Form
    {
        public SubmitForm()
        {
            InitializeComponent();
        }
        private void SubmitForm_Load(object sender, EventArgs e)//下拉列表的数据导入
        {
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from judgecircle";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(selectsql, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataTable _table = ds.Tables[0];

            judgetime.DataSource = _table;
            judgetime.DisplayMember = "judgecirclename";
            judgetime.ValueMember = "judgecircleid";
        }
        private void submit_Click(object sender, EventArgs e)
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select  judgecircle.judgecirclename='" + judgetime.SelectedValue + "'"
                      + "advice='" + advice.Text + "'from adre，judgecircle where judgecircle where adre.judgecirclename=judgecircle.judgecirclename";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            _sql = _sql + " and judgecircle.judgecircleid='" + judgetime.SelectedValue + "'";
            try
            {
                if (advice.Text.Trim() == "")
                {
                    MessageBox.Show("输入不能为空！",
                                         "错误！",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                }
                else  if (judgetime.Text == "")
                {
                    //提示对话框
                    MessageBox.Show(this, "评分周期不能为空！请选择！", "提示对话框", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    conn.Open();

                    _sql = "insert into adre(judgecirclename,advice) values('" + judgetime.Text+ "','" + advice.Text + "')";
                    cmd = new SqlCommand(_sql, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("意见提交成功！",
                                     "提示",
                                     MessageBoxButtons.OK,
                                     MessageBoxIcon.Information);
                }
            }
            finally
            {
                conn.Close();
            }
            advice.Clear();
           
        }
    }
}
