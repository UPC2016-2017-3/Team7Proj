﻿namespace WindowsFormsApplication1
{
    partial class JudgeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.score = new System.Windows.Forms.TextBox();
            this.scorebtn = new System.Windows.Forms.Button();
            this.scoregb = new System.Windows.Forms.GroupBox();
            this.time = new System.Windows.Forms.GroupBox();
            this.judgecircleid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.judgetime = new System.Windows.Forms.TextBox();
            this.building = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tb6 = new System.Windows.Forms.TextBox();
            this.l6 = new System.Windows.Forms.Label();
            this.tb3 = new System.Windows.Forms.TextBox();
            this.l4 = new System.Windows.Forms.Label();
            this.sequence = new System.Windows.Forms.TextBox();
            this.l2 = new System.Windows.Forms.Label();
            this.buildingid = new System.Windows.Forms.TextBox();
            this.l3 = new System.Windows.Forms.Label();
            this.roomid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.scoregb.SuspendLayout();
            this.time.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(208, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "请输入寝室:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(223, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "寝室得分:";
            // 
            // score
            // 
            this.score.Location = new System.Drawing.Point(305, 174);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(121, 25);
            this.score.TabIndex = 9;
            // 
            // scorebtn
            // 
            this.scorebtn.Location = new System.Drawing.Point(337, 307);
            this.scorebtn.Name = "scorebtn";
            this.scorebtn.Size = new System.Drawing.Size(89, 34);
            this.scorebtn.TabIndex = 4;
            this.scorebtn.Text = "确认提交";
            this.scorebtn.UseVisualStyleBackColor = true;
            this.scorebtn.Click += new System.EventHandler(this.scorebtn_Click);
            // 
            // scoregb
            // 
            this.scoregb.Controls.Add(this.time);
            this.scoregb.Controls.Add(this.tb6);
            this.scoregb.Controls.Add(this.l6);
            this.scoregb.Controls.Add(this.tb3);
            this.scoregb.Controls.Add(this.l4);
            this.scoregb.Controls.Add(this.sequence);
            this.scoregb.Controls.Add(this.l2);
            this.scoregb.Controls.Add(this.buildingid);
            this.scoregb.Controls.Add(this.scorebtn);
            this.scoregb.Controls.Add(this.l3);
            this.scoregb.Controls.Add(this.roomid);
            this.scoregb.Controls.Add(this.label1);
            this.scoregb.Controls.Add(this.label2);
            this.scoregb.Controls.Add(this.score);
            this.scoregb.Location = new System.Drawing.Point(97, 128);
            this.scoregb.Name = "scoregb";
            this.scoregb.Size = new System.Drawing.Size(614, 360);
            this.scoregb.TabIndex = 5;
            this.scoregb.TabStop = false;
            // 
            // time
            // 
            this.time.Controls.Add(this.judgecircleid);
            this.time.Controls.Add(this.label5);
            this.time.Controls.Add(this.judgetime);
            this.time.Controls.Add(this.building);
            this.time.Controls.Add(this.label4);
            this.time.Location = new System.Drawing.Point(0, 7);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(631, 353);
            this.time.TabIndex = 12;
            this.time.TabStop = false;
            // 
            // judgecircleid
            // 
            this.judgecircleid.Location = new System.Drawing.Point(298, 87);
            this.judgecircleid.Name = "judgecircleid";
            this.judgecircleid.Size = new System.Drawing.Size(121, 25);
            this.judgecircleid.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(176, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "请输入评分次序：";
            // 
            // judgetime
            // 
            this.judgetime.Location = new System.Drawing.Point(298, 115);
            this.judgetime.Name = "judgetime";
            this.judgetime.Size = new System.Drawing.Size(121, 25);
            this.judgetime.TabIndex = 5;
            this.judgetime.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // building
            // 
            this.building.Location = new System.Drawing.Point(338, 180);
            this.building.Name = "building";
            this.building.Size = new System.Drawing.Size(89, 34);
            this.building.TabIndex = 9;
            this.building.Text = "确认";
            this.building.UseVisualStyleBackColor = true;
            this.building.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(176, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "请输入评分周期：";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tb6
            // 
            this.tb6.Location = new System.Drawing.Point(303, 41);
            this.tb6.Name = "tb6";
            this.tb6.Size = new System.Drawing.Size(121, 25);
            this.tb6.TabIndex = 17;
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Location = new System.Drawing.Point(178, 50);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(127, 15);
            this.l6.TabIndex = 16;
            this.l6.Text = "请输入评分次序：";
            // 
            // tb3
            // 
            this.tb3.Location = new System.Drawing.Point(305, 205);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(121, 25);
            this.tb3.TabIndex = 15;
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Location = new System.Drawing.Point(193, 210);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(105, 15);
            this.l4.TabIndex = 14;
            this.l4.Text = "查分学生学号:";
            // 
            // sequence
            // 
            this.sequence.Location = new System.Drawing.Point(304, 105);
            this.sequence.Name = "sequence";
            this.sequence.Size = new System.Drawing.Size(121, 25);
            this.sequence.TabIndex = 11;
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Location = new System.Drawing.Point(178, 112);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(120, 15);
            this.l2.TabIndex = 10;
            this.l2.Text = "请输入评分序号:";
            // 
            // buildingid
            // 
            this.buildingid.Location = new System.Drawing.Point(304, 72);
            this.buildingid.Name = "buildingid";
            this.buildingid.Size = new System.Drawing.Size(121, 25);
            this.buildingid.TabIndex = 12;
            // 
            // l3
            // 
            this.l3.AutoSize = true;
            this.l3.Location = new System.Drawing.Point(208, 80);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(90, 15);
            this.l3.TabIndex = 13;
            this.l3.Text = "请输入楼号:";
            // 
            // roomid
            // 
            this.roomid.Location = new System.Drawing.Point(305, 140);
            this.roomid.Name = "roomid";
            this.roomid.Size = new System.Drawing.Size(121, 25);
            this.roomid.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("华文新魏", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(257, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(274, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "欢迎进行本次评分！";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(692, 536);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 32);
            this.button2.TabIndex = 7;
            this.button2.Text = "退出";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // JudgeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 580);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.scoregb);
            this.Name = "JudgeForm";
            this.Text = " ";
            this.scoregb.ResumeLayout(false);
            this.scoregb.PerformLayout();
            this.time.ResumeLayout(false);
            this.time.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox score;
        private System.Windows.Forms.Button scorebtn;
        private System.Windows.Forms.GroupBox scoregb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox roomid;
        private System.Windows.Forms.TextBox judgetime;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button building;
        private System.Windows.Forms.GroupBox time;
        private System.Windows.Forms.TextBox sequence;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.TextBox buildingid;
        private System.Windows.Forms.TextBox tb3;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.TextBox judgecircleid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb6;
        private System.Windows.Forms.Label l6;
    }
}