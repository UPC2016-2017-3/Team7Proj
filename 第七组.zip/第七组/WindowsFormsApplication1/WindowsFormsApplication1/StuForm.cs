﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class StuForm : Form
    {
        public StuForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void 返回_Click(object sender, EventArgs e)
        {
            
                MessageBox.Show("确认退出？",
                               "提示！",
                        MessageBoxButtons.OK,          
                       MessageBoxIcon.Information);
          
            MainForm f2 = new MainForm();
            this.Hide();
            f2.Show();
        }
      
        private void 意见查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            result.BringToFront();
        }
     
        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modify.BringToFront();
        }

        private void 意见上传ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SubmitForm s = new SubmitForm();
            s.ShowDialog();
        }

        private void judgetime_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)//评分周期选择匹配查询结果
        {
            if (judgetime.Text == "")
            {
                //提示对话框
                MessageBox.Show(this, "评分周期不能为空！请选择！", "提示对话框", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
                string _sql = "select sequence as '序号',judgecircle.judgecirclename as '评分周期',buildingid as '楼号',roomid as '寝室号',scores as '分数',"
                              + "stuid as '评分学生学号',imagelinks as '照片链接' from  Score,judgecircle where Score.judgecircleid=judgecircle.judgecircleid ";

                if (judgetime.SelectedValue.ToString().Trim() == "-1") { }
                else
                {
                    _sql = _sql + " and judgecircle.judgecircleid='" + judgetime.SelectedValue + "'";
                }

                SqlConnection conn = new SqlConnection(connStr);
                SqlDataAdapter sda = new SqlDataAdapter(_sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                DataTable _table = ds.Tables[0];
                int count = _table.Rows.Count;
                scoregdv.DataSource = ds.Tables[0].DefaultView;
                conn.Close();
              
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//从下拉列表中选择周期
        {
           
        }

        private void password_Click(object sender, EventArgs e)//修改密码
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select count(*) from Student where stuid='" + zh.Text + "' ,stupassword='" + cuspassword.Text + "'";
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand(_sql, conn);
            try
            {
                conn.Open();


                _sql = "update Student set stupassword='" + newpassword.Text + "'";

                cmd = new SqlCommand(_sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("更改成功！",
                                 "提示",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }

        private void scoregdv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void StuForm_Load(object sender, EventArgs e)//下拉列表的数据导入
        {
            string str = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            string selectsql = "Select * from judgecircle";
            SqlCommand cmd = new SqlCommand(selectsql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(selectsql, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataTable _table = ds.Tables[0];

            judgetime.DataSource = _table;
            judgetime.DisplayMember = "judgecirclename";
            judgetime.ValueMember = "judgecircleid";            
        }

        private void button1_Click(object sender, EventArgs e)//
        {
            string connStr = @"Data Source=JKERH945;Initial catalog=StuRoom;integrated Security=True";
            string _sql = "select sequence as '序号',judgecircle.judgecirclename as '评分周期',buildingid as '楼号',"
                          + "roomid as '寝室号',scores as '分数',"
                          + "stuid as '评分学生学号',imagelinks as '照片链接' from  Score,judgecircle where Score.judgecircleid=judgecircle.judgecircleid ";

            if (buildingid.Text.Trim() == "") { _sql = _sql + "and roomid='" + roomid1.Text.Trim() + "'"; }
            else if (roomid1.Text.Trim() == "") { _sql = _sql + " and buildingid='" + buildingid.Text.Trim() + "'"; }
            else
            {
                _sql = _sql + " and buildingid='" + buildingid.Text.Trim() + "',roomid='" + roomid1.Text.Trim() + "'";
            }

            SqlConnection conn = new SqlConnection(connStr);
            SqlDataAdapter sda = new SqlDataAdapter(_sql, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataTable _table = ds.Tables[0];
            int count = _table.Rows.Count;
            scoregdv.DataSource = ds.Tables[0].DefaultView;
            conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void 意见和处理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Advice a = new Advice();
            a.ShowDialog();
            
        }

        private void submit_Click(object sender, EventArgs e)
        {

        }

    }
}
