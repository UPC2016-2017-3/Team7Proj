﻿namespace WindowsFormsApplication1
{
    partial class Advice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.result = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.scoregdv = new System.Windows.Forms.DataGridView();
            this.judgetime = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).BeginInit();
            this.SuspendLayout();
            // 
            // result
            // 
            this.result.Controls.Add(this.button1);
            this.result.Controls.Add(this.scoregdv);
            this.result.Controls.Add(this.judgetime);
            this.result.Controls.Add(this.label1);
            this.result.Location = new System.Drawing.Point(72, 74);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(732, 531);
            this.result.TabIndex = 12;
            this.result.TabStop = false;
            this.result.Text = "意见和结果";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(480, 119);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 26);
            this.button1.TabIndex = 7;
            this.button1.Text = "确定";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // scoregdv
            // 
            this.scoregdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scoregdv.Location = new System.Drawing.Point(61, 151);
            this.scoregdv.Name = "scoregdv";
            this.scoregdv.RowTemplate.Height = 27;
            this.scoregdv.Size = new System.Drawing.Size(623, 319);
            this.scoregdv.TabIndex = 0;
            // 
            // judgetime
            // 
            this.judgetime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.judgetime.FormattingEnabled = true;
            this.judgetime.Location = new System.Drawing.Point(338, 60);
            this.judgetime.Name = "judgetime";
            this.judgetime.Size = new System.Drawing.Size(121, 23);
            this.judgetime.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(259, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "打分周期：";
            // 
            // Advice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 690);
            this.Controls.Add(this.result);
            this.Name = "Advice";
            this.Text = "学生意见与处理结果：";
            this.Load += new System.EventHandler(this.AdviceForm_Load);
            this.result.ResumeLayout(false);
            this.result.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox result;
        private System.Windows.Forms.DataGridView scoregdv;
        private System.Windows.Forms.ComboBox judgetime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}