﻿namespace WindowsFormsApplication1
{
    partial class StuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.意见上传ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.意见和处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.result = new System.Windows.Forms.GroupBox();
            this.buildingid = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.roomid = new System.Windows.Forms.Label();
            this.scoregdv = new System.Windows.Forms.DataGridView();
            this.roomid1 = new System.Windows.Forms.TextBox();
            this.judgetime = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.again = new System.Windows.Forms.Button();
            this.modify = new System.Windows.Forms.GroupBox();
            this.password = new System.Windows.Forms.Button();
            this.cuspassword = new System.Windows.Forms.TextBox();
            this.newpassword = new System.Windows.Forms.TextBox();
            this.zh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.返回 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).BeginInit();
            this.modify.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolStripMenuItem
            // 
            this.ToolStripMenuItem.Name = "ToolStripMenuItem";
            this.ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.ToolStripMenuItem.Text = "结果查询";
            this.ToolStripMenuItem.Click += new System.EventHandler(this.意见查询ToolStripMenuItem_Click);
            // 
            // 意见上传ToolStripMenuItem
            // 
            this.意见上传ToolStripMenuItem.Name = "意见上传ToolStripMenuItem";
            this.意见上传ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.意见上传ToolStripMenuItem.Text = "意见上传";
            this.意见上传ToolStripMenuItem.Click += new System.EventHandler(this.意见上传ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem,
            this.意见上传ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.意见和处理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(21, 21);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(347, 28);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 意见和处理ToolStripMenuItem
            // 
            this.意见和处理ToolStripMenuItem.Name = "意见和处理ToolStripMenuItem";
            this.意见和处理ToolStripMenuItem.Size = new System.Drawing.Size(96, 24);
            this.意见和处理ToolStripMenuItem.Text = "意见和处理";
            this.意见和处理ToolStripMenuItem.Click += new System.EventHandler(this.意见和处理ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.result);
            this.groupBox1.Controls.Add(this.modify);
            this.groupBox1.Controls.Add(this.menuStrip1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(896, 656);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请选择";
            // 
            // result
            // 
            this.result.Controls.Add(this.buildingid);
            this.result.Controls.Add(this.button3);
            this.result.Controls.Add(this.label6);
            this.result.Controls.Add(this.roomid);
            this.result.Controls.Add(this.scoregdv);
            this.result.Controls.Add(this.roomid1);
            this.result.Controls.Add(this.judgetime);
            this.result.Controls.Add(this.label1);
            this.result.Controls.Add(this.again);
            this.result.Location = new System.Drawing.Point(39, 68);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(834, 568);
            this.result.TabIndex = 11;
            this.result.TabStop = false;
            this.result.Text = "结果查询";
            // 
            // buildingid
            // 
            this.buildingid.Location = new System.Drawing.Point(503, 52);
            this.buildingid.Name = "buildingid";
            this.buildingid.Size = new System.Drawing.Size(100, 25);
            this.buildingid.TabIndex = 13;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(202, 112);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 25);
            this.button3.TabIndex = 9;
            this.button3.Text = "确认";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(445, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "楼号：";
            // 
            // roomid
            // 
            this.roomid.AutoSize = true;
            this.roomid.Location = new System.Drawing.Point(430, 91);
            this.roomid.Name = "roomid";
            this.roomid.Size = new System.Drawing.Size(67, 15);
            this.roomid.TabIndex = 8;
            this.roomid.Text = "寝室号：";
            // 
            // scoregdv
            // 
            this.scoregdv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scoregdv.Location = new System.Drawing.Point(61, 151);
            this.scoregdv.Name = "scoregdv";
            this.scoregdv.RowTemplate.Height = 27;
            this.scoregdv.Size = new System.Drawing.Size(623, 319);
            this.scoregdv.TabIndex = 0;
            this.scoregdv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.scoregdv_CellContentClick);
            // 
            // roomid1
            // 
            this.roomid1.Location = new System.Drawing.Point(503, 85);
            this.roomid1.Name = "roomid1";
            this.roomid1.Size = new System.Drawing.Size(100, 25);
            this.roomid1.TabIndex = 7;
            // 
            // judgetime
            // 
            this.judgetime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.judgetime.FormattingEnabled = true;
            this.judgetime.Location = new System.Drawing.Point(156, 58);
            this.judgetime.Name = "judgetime";
            this.judgetime.Size = new System.Drawing.Size(121, 23);
            this.judgetime.TabIndex = 6;
            this.judgetime.SelectedIndexChanged += new System.EventHandler(this.judgetime_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "打分周期：";
            // 
            // again
            // 
            this.again.Location = new System.Drawing.Point(520, 112);
            this.again.Name = "again";
            this.again.Size = new System.Drawing.Size(83, 25);
            this.again.TabIndex = 3;
            this.again.Text = "确认";
            this.again.UseVisualStyleBackColor = true;
            this.again.Click += new System.EventHandler(this.button1_Click);
            // 
            // modify
            // 
            this.modify.Controls.Add(this.password);
            this.modify.Controls.Add(this.cuspassword);
            this.modify.Controls.Add(this.newpassword);
            this.modify.Controls.Add(this.zh);
            this.modify.Controls.Add(this.label4);
            this.modify.Controls.Add(this.label3);
            this.modify.Controls.Add(this.label2);
            this.modify.Location = new System.Drawing.Point(39, 68);
            this.modify.Name = "modify";
            this.modify.Size = new System.Drawing.Size(834, 568);
            this.modify.TabIndex = 2;
            this.modify.TabStop = false;
            this.modify.Text = "修改密码";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(376, 283);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(85, 32);
            this.password.TabIndex = 6;
            this.password.Text = "确认修改";
            this.password.UseVisualStyleBackColor = true;
            this.password.Click += new System.EventHandler(this.password_Click);
            // 
            // cuspassword
            // 
            this.cuspassword.Location = new System.Drawing.Point(316, 141);
            this.cuspassword.Name = "cuspassword";
            this.cuspassword.Size = new System.Drawing.Size(145, 25);
            this.cuspassword.TabIndex = 5;
            // 
            // newpassword
            // 
            this.newpassword.Location = new System.Drawing.Point(316, 192);
            this.newpassword.Name = "newpassword";
            this.newpassword.Size = new System.Drawing.Size(145, 25);
            this.newpassword.TabIndex = 4;
            // 
            // zh
            // 
            this.zh.Location = new System.Drawing.Point(316, 91);
            this.zh.Name = "zh";
            this.zh.Size = new System.Drawing.Size(145, 25);
            this.zh.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(213, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "输入新密码：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "输入旧密码：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(258, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "账号：";
            // 
            // 返回
            // 
            this.返回.Location = new System.Drawing.Point(825, 674);
            this.返回.Name = "返回";
            this.返回.Size = new System.Drawing.Size(83, 41);
            this.返回.TabIndex = 9;
            this.返回.Text = "退出";
            this.返回.UseVisualStyleBackColor = true;
            this.返回.Click += new System.EventHandler(this.返回_Click);
            // 
            // StuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 722);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.返回);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "StuForm";
            this.Text = "StuForm";
            this.Load += new System.EventHandler(this.StuForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.result.ResumeLayout(false);
            this.result.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoregdv)).EndInit();
            this.modify.ResumeLayout(false);
            this.modify.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 意见上传ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button 返回;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.GroupBox modify;
        private System.Windows.Forms.Button password;
        private System.Windows.Forms.TextBox cuspassword;
        private System.Windows.Forms.TextBox newpassword;
        private System.Windows.Forms.TextBox zh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem 意见和处理ToolStripMenuItem;
        private System.Windows.Forms.GroupBox result;
        private System.Windows.Forms.TextBox buildingid;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label roomid;
        private System.Windows.Forms.DataGridView scoregdv;
        private System.Windows.Forms.TextBox roomid1;
        private System.Windows.Forms.ComboBox judgetime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button again;

    }
}